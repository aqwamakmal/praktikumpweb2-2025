<?php
  // Mendefinisikan variabel
    $nama ="agus";
    $umur ="24"
    $bb = "45";

        echo "Nama saya adalah : " .$nama;
        echo "<br/> umur : " .$umur. "Tahun";
         echo "<br/> Berat badan :" .$bb. "Kg";
 ?>