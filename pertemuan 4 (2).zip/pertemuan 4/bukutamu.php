<?php

    class BukuTamu {
        public $timestamp;
        public $fullname;
        public $email;
        public $message;

    }
?>